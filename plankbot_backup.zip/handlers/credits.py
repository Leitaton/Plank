"""
Plank — Credit & plan commands: /daily, /balance, /redeem.
"""

import time

from telegram import Update
from telegram.ext import ContextTypes

from config import PLANS, DAILY_COOLDOWN_HOURS, BRAND_NAME
from database import (
    ensure_user, get_user, add_credits, set_last_daily,
    set_plan, redeem_code as db_redeem, run_in_db,
)
from utils.emojis import section, bold, separator, E_MONEY, E_GIFT, E_ARROW, E_CHECK, E_CROSS, E_STAR, E_CLOCK, E_HEART, E_WARN, get_emoji, get_plan_emoji
from utils.helpers import credits_display, get_plan_info
from handlers.start import membership_guard


async def daily_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await membership_guard(update, context):
        return

    user = update.effective_user
    db_user = await run_in_db(ensure_user, user.id, user.username or "")

    cooldown = DAILY_COOLDOWN_HOURS * 3600
    elapsed = time.time() - db_user["last_daily"]
    if elapsed < cooldown:
        remaining = cooldown - elapsed
        hours = int(remaining // 3600)
        mins = int((remaining % 3600) // 60)
        await update.message.reply_text(
            f"{section(E_CLOCK, 'Daily Claimed')} · next in {bold(f'{hours}h {mins}m')}\n"
        )
        return

    plan_info = get_plan_info(db_user["plan"])
    bonus = plan_info.get("daily_bonus", 25)
    await run_in_db(add_credits, user.id, bonus)
    await run_in_db(set_last_daily, user.id)

    updated = await run_in_db(get_user, user.id)
    await update.message.reply_text(
        f"{section(E_GIFT, 'Daily')}\n\n"
        f"╰ +{bold(str(bonus))} credits · total {bold(credits_display(updated['credits']))}\n"
    )


async def balance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await membership_guard(update, context):
        return

    user = update.effective_user
    db_user = await run_in_db(ensure_user, user.id, user.username or "")
    cr = db_user["credits"]
    plan_info = get_plan_info(db_user["plan"])

    # Resolve plan emoji from dynamic config
    plan_emoji = get_plan_emoji(db_user["plan"])

    await update.message.reply_text(
        f"{section(E_MONEY, 'Balance')}\n\n"
        f"╰ {plan_emoji} {bold(plan_info['display'])} · "
        f"{bold(credits_display(cr))} cr · "
        f"{plan_info['workers']}w\n"
    )


async def redeem_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await membership_guard(update, context):
        return

    user = update.effective_user
    await run_in_db(ensure_user, user.id, user.username or "")

    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            f"{section(E_WARN, '/redeem PLANK-PLAN-XXXXXXXX')}\n"
        )
        return

    code = context.args[0].strip().upper()
    result = await run_in_db(db_redeem, code, user.id)

    if not result:
        await update.message.reply_text(
            f"{section(E_CROSS, 'invalid or used code')}\n"
        )
        return

    plan = result["plan"]
    duration = result["duration_sec"]
    await run_in_db(set_plan, user.id, plan, duration)
    plan_info = get_plan_info(plan)
    days = duration // 86400

    plan_emoji = get_plan_emoji(plan)

    await update.message.reply_text(
        f"{section(E_STAR, 'Redeemed')}\n\n"
        f"╰ {plan_emoji} {bold(plan_info['display'])} · {bold(f'{days}d')} · {plan_info['workers']}w\n"
    )

