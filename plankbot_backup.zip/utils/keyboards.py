"""
Plank — Inline keyboard builders.
"""

import re
from telegram import InlineKeyboardButton as TelegramInlineKeyboardButton, InlineKeyboardMarkup

CUSTOM_EMOJI_PATTERN = re.compile(r'<tg-emoji emoji-id="(\d+)">([^<]*)</tg-emoji>')

class InlineKeyboardButton(TelegramInlineKeyboardButton):
    def __init__(self, text: str, *args, **kwargs):
        text_str = str(text)
        match = CUSTOM_EMOJI_PATTERN.search(text_str)
        if match:
            emoji_id = match.group(1)
            clean_text = CUSTOM_EMOJI_PATTERN.sub("", text_str).strip()
            api_kwargs = kwargs.setdefault("api_kwargs", {})
            api_kwargs["icon_custom_emoji_id"] = emoji_id
            super().__init__(clean_text, *args, **kwargs)
        else:
            super().__init__(text, *args, **kwargs)


from config import CHAT_INVITE_LINK, CHANNEL_INVITE_LINK, CUSTOM_PLAN_CONTACT
from utils.emojis import (
    E_CHECK, E_STAR, E_DIAMOND, E_DOC, E_MONEY, E_CROSS, E_ERROR,
    E_STOP, E_RETRY, E_USER, E_CHART, E_GIFT, E_KEY, E_BAN,
    E_CHANNEL, E_GROUP, E_BROADCAST, E_CHAIN, get_emoji
)


def join_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(f"{E_CHANNEL} Join Channel", url=CHANNEL_INVITE_LINK),
            InlineKeyboardButton(f"{E_GROUP} Join Group", url=CHAT_INVITE_LINK),
        ],
        [InlineKeyboardButton(f"{E_CHECK} Verify", callback_data="verify_join")],
    ])


def plans_keyboard() -> InlineKeyboardMarkup:
    cobble_emoji = get_emoji("cobblestone", "⚡️")
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"{cobble_emoji} Cobblestone — $5/wk", callback_data="plan_cobblestone")],
        [InlineKeyboardButton(f"{E_STAR} Diamond — $15/mo", callback_data="plan_diamond")],
        [InlineKeyboardButton(f"{E_DIAMOND} Bedrock — $30/mo", callback_data="plan_bedrock")],
        [InlineKeyboardButton(f"{E_DOC} Custom Plans — {CUSTOM_PLAN_CONTACT}", url=f"https://t.me/{CUSTOM_PLAN_CONTACT.lstrip('@')}")],
    ])


def mass_keyboard(session_id: str, approved: int = 0, charged: int = 0,
                   dead: int = 0, error: int = 0, stopped: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if charged > 0:
        rows.append([InlineKeyboardButton(f"{E_MONEY} Charged ({charged})", callback_data=f"mview_charged_{session_id}")])
    if approved > 0:
        rows.append([InlineKeyboardButton(f"{E_CHECK} Approved ({approved})", callback_data=f"mview_approved_{session_id}")])
    if dead > 0:
        rows.append([InlineKeyboardButton(f"{E_CROSS} Dead ({dead})", callback_data=f"mview_dead_{session_id}")])
    if error > 0:
        rows.append([InlineKeyboardButton(f"{E_ERROR} Error ({error})", callback_data=f"mview_error_{session_id}")])
    if not stopped:
        rows.append([InlineKeyboardButton(f"{E_STOP} Stop", callback_data=f"mstop_{session_id}")])
    else:
        if error > 0:
            rows.append([InlineKeyboardButton(f"{E_RETRY} Retry Errors", callback_data=f"mretry_{session_id}")])
    return InlineKeyboardMarkup(rows)


def admin_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(f"{E_USER} Users", callback_data="admin_users"),
            InlineKeyboardButton(f"{E_CHART} Stats", callback_data="admin_stats"),
        ],
        [
            InlineKeyboardButton(f"{E_GIFT} Gen Codes", callback_data="admin_genplan"),
            InlineKeyboardButton(f"{E_KEY} Set Plan", callback_data="admin_setplan"),
        ],
        [
            InlineKeyboardButton(f"{E_MONEY} Add Credits", callback_data="admin_addcredits"),
            InlineKeyboardButton(f"{E_BAN} Ban/Unban", callback_data="admin_ban"),
        ],
        [
            InlineKeyboardButton(f"{E_BROADCAST} Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton(f"{E_CHAIN} Proxies", callback_data="admin_proxies"),
        ],
    ])

