import unittest
import os
import json
import asyncio
import time
from unittest.mock import patch, MagicMock, AsyncMock

# Overwrite database path for test isolation
import config
config.DATABASE_PATH = "test_plankbot.db"

import database
database.DATABASE_PATH = "test_plankbot.db"
database._local = type('', (), {})() # reset thread local connection for this test thread

from database import init_db, save_mass_session, get_mass_session
from utils.emojis import DynamicEmoji, get_emoji, reload_emojis, E_SECTION_OPEN, E_SECTION_CLOSE, get_plan_emoji
from utils.checkers import check_shopify, get_shopify_sites

class TestPlankBot(unittest.TestCase):
    def setUp(self):
        # Initialize test database
        if os.path.exists("test_plankbot.db"):
            os.remove("test_plankbot.db")
        init_db()
        self.original_sites_file = config.SHOPIFY_SITES_FILE
        config.SHOPIFY_SITES_FILE = "test_sites.txt"
        
        # Backup emojis.json
        self.emojis_backup = None
        if os.path.exists("emojis.json"):
            with open("emojis.json", "r", encoding="utf-8") as f:
                self.emojis_backup = f.read()

    def tearDown(self):
        # Close connection and clean up
        if hasattr(database._local, "conn") and database._local.conn:
            try:
                database._local.conn.close()
            except Exception:
                pass
            database._local.conn = None
        if os.path.exists("test_plankbot.db"):
            try:
                os.remove("test_plankbot.db")
            except Exception:
                pass
        config.SHOPIFY_SITES_FILE = self.original_sites_file
        if os.path.exists("test_sites.txt"):
            try:
                os.remove("test_sites.txt")
            except Exception:
                pass
        # Restore emojis.json backup
        if self.emojis_backup is not None:
            with open("emojis.json", "w", encoding="utf-8") as f:
                f.write(self.emojis_backup)
        elif os.path.exists("emojis.json"):
            try:
                os.remove("emojis.json")
            except Exception:
                pass
        reload_emojis()

    def test_dynamic_emojis(self):
        # Remove emojis.json to test defaults
        if os.path.exists("emojis.json"):
            os.remove("emojis.json")
        reload_emojis()
        
        # Test default emojis
        self.assertEqual(str(DynamicEmoji("stop", "⊖")), "⊖")
        self.assertEqual(str(DynamicEmoji("retry", "🔄")), "🔄")
        self.assertEqual(str(E_SECTION_OPEN), "꒰")
        self.assertEqual(str(E_SECTION_CLOSE), "꒱")
        self.assertEqual(get_plan_emoji("dirt"), "🟤")
        self.assertEqual(get_plan_emoji("cobblestone"), "⚡️")
        
        # Test override from emojis.json
        # Create a mock emojis.json file
        with open("emojis.json", "w", encoding="utf-8") as f:
            json.dump({
                "stop": "🛑",
                "retry": "♻️",
                "section_open": "「",
                "section_close": "」",
                "dirt": "💩"
            }, f)
        
        reload_emojis()
        self.assertEqual(str(DynamicEmoji("stop", "⊖")), "🛑")
        self.assertEqual(str(DynamicEmoji("retry", "🔄")), "♻️")
        self.assertEqual(str(E_SECTION_OPEN), "「")
        self.assertEqual(str(E_SECTION_CLOSE), "」")
        self.assertEqual(get_plan_emoji("dirt"), "💩")

    def test_custom_telegram_emoji_parsing(self):
        # 1. Test custom emoji rendering in DynamicEmoji when loaded from emojis.json
        # Mock emojis.json with digital strings, objects, and id:fallback format
        with open("emojis.json", "w", encoding="utf-8") as f:
            json.dump({
                "stop": "543210987654321",
                "retry": {"id": "987654321012345", "fallback": "🔄"},
                "ban": "<tg-emoji id=\"1111111111111\">🚫</tg-emoji>",
                "bolt": "999888777:⚡"
            }, f)
        
        reload_emojis()
        
        # stop: custom emoji ID represented as digit string
        self.assertEqual(str(DynamicEmoji("stop", "⊖")), '<tg-emoji emoji-id="543210987654321">⊖</tg-emoji>')
        
        # retry: custom emoji ID represented as dict
        self.assertEqual(str(DynamicEmoji("retry", "🔄")), '<tg-emoji emoji-id="987654321012345">🔄</tg-emoji>')
        
        # ban: custom emoji ID represented as raw HTML
        self.assertEqual(str(DynamicEmoji("ban", "🚫")), '<tg-emoji emoji-id="1111111111111">🚫</tg-emoji>')
        
        # bolt: custom emoji ID represented as id:fallback string
        self.assertEqual(str(DynamicEmoji("bolt", "⚡️")), '<tg-emoji emoji-id="999888777">⚡</tg-emoji>')
        
        # 2. Test InlineKeyboardButton subclass custom emoji extraction and button formatting
        from utils.keyboards import InlineKeyboardButton
        
        # Test custom emoji as digit string stopping
        btn_stop = InlineKeyboardButton(f"{DynamicEmoji('stop', '⊖')} Stop Process", callback_data="stop_data")
        serialized_stop = btn_stop.to_dict()
        self.assertEqual(serialized_stop["text"], "Stop Process")
        self.assertEqual(serialized_stop["icon_custom_emoji_id"], "543210987654321")
        
        # Test custom emoji as dict retry
        btn_retry = InlineKeyboardButton(f"{DynamicEmoji('retry', '🔄')} Retry Errors", callback_data="retry_data")
        serialized_retry = btn_retry.to_dict()
        self.assertEqual(serialized_retry["text"], "Retry Errors")
        self.assertEqual(serialized_retry["icon_custom_emoji_id"], "987654321012345")

        # Test normal unicode emoji button (no custom ID)
        btn_normal = InlineKeyboardButton("📢 Broadcast Message", callback_data="broadcast_data")
        serialized_normal = btn_normal.to_dict()
        self.assertEqual(serialized_normal["text"], "📢 Broadcast Message")
        self.assertNotIn("icon_custom_emoji_id", serialized_normal)

    def test_database_mass_sessions(self):
        # Create a dummy session state
        dummy_state = {
            "id": "test_session_123",
            "user_id": 99999,
            "username": "test_user",
            "gate": "shopify",
            "total": 10,
            "processed": 5,
            "charged": 1,
            "approved": 2,
            "dead": 2,
            "error": 0,
            "stopped": False,
            "site": "example.com",
            "workers": 5,
            "cooldown": 2.0,
            "last_active": 123456789.0,
            "msg_id": 5555,
            "chat_id": 6666,
            "checker_fn": lambda x: x,
            "cards": ["1111|12|28|111", "2222|12|28|222"],
            "results": {"error": [], "charged": ["1111"]},
            "user_proxies": ["http://proxy.com"]
        }
        
        save_mass_session(dummy_state)
        loaded = get_mass_session("test_session_123")
        
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded["id"], "test_session_123")
        self.assertEqual(loaded["user_id"], 99999)
        self.assertEqual(loaded["username"], "test_user")
        self.assertEqual(loaded["gate"], "shopify")
        self.assertEqual(loaded["total"], 10)
        self.assertEqual(loaded["processed"], 5)
        self.assertEqual(loaded["charged"], 1)
        self.assertEqual(loaded["approved"], 2)
        self.assertEqual(loaded["dead"], 2)
        self.assertFalse(loaded["stopped"])
        self.assertEqual(loaded["site"], "example.com")
        self.assertEqual(loaded["workers"], 5)
        self.assertEqual(loaded["cooldown"], 2.0)
        self.assertEqual(loaded["msg_id"], 5555)
        self.assertEqual(loaded["chat_id"], 6666)
        
        # Test nonexistent session
        self.assertIsNone(get_mass_session("nonexistent"))

    def test_invalid_cvc_masking(self):
        # Mock client session and response
        mock_session = MagicMock()
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value={"card_response": "INVALID_CVC", "price": "0.00", "gate": "Shopify Payments", "site": "example.com"})
        
        mock_cm = AsyncMock()
        mock_cm.__aenter__.return_value = mock_resp
        mock_session.get.return_value = mock_cm
        
        with patch("utils.checkers._get_api_session", AsyncMock(return_value=mock_session)):
            res = asyncio.run(check_shopify("4111111111111111", "12", "2028", "123", site="example.com"))
        
        self.assertEqual(res["Response"], "3DS_REQUIRED")
        self.assertEqual(res["Approved"], "True")

    @patch("utils.checkers.get_shopify_sites")
    def test_product_over_main_retry_logic(self, mock_get_sites):
        # Configure sites
        mock_get_sites.return_value = ["site1.com", "site2.com", "site3.com", "site4.com", "site5.com", "site6.com"]
        
        mock_session = MagicMock()
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value={"card_response": "PRODUCT_OVER_MAIN", "price": "0.00", "gate": "Shopify Payments", "site": "some-site.com"})
        
        mock_cm = AsyncMock()
        mock_cm.__aenter__.return_value = mock_resp
        mock_session.get.return_value = mock_cm
        
        with patch("utils.checkers._get_api_session", AsyncMock(return_value=mock_session)):
            res = asyncio.run(check_shopify("4111111111111111", "12", "2028", "123", site="site1.com"))
        
        # Since we kept failing, it should have rotated across all sites and finally returned "NO_PRODUCT"
        self.assertEqual(res["Response"], "NO_PRODUCT")
        
        # Check that it called get 6 times in total (1 initial + 5 retries)
        self.assertEqual(mock_session.get.call_count, 6)
        
        # Verify that all target sites were unique (site rotation)
        called_sites = []
        for call in mock_session.get.call_args_list:
            called_sites.append(call[1]["params"].get("site"))
        
        # The sites list contains unique sites
        self.assertEqual(len(set(called_sites)), 6)

    def test_credits_unlimited_and_limited(self):
        from database import get_db, ensure_user, add_credits, deduct_credits, get_credits

        # Create a test user
        user_id = 12345
        ensure_user(user_id, "test_credits_user")

        # By default, users get plan default credits (500)
        self.assertEqual(get_credits(user_id), 500)

        # 1. Test normal deduction
        self.assertTrue(deduct_credits(user_id, 100))
        self.assertEqual(get_credits(user_id), 400)

        # 2. Test deduction when not enough credits
        self.assertFalse(deduct_credits(user_id, 500))
        self.assertEqual(get_credits(user_id), 400)

        # 3. Test normal add
        add_credits(user_id, 200)
        self.assertEqual(get_credits(user_id), 600)

        # 4. Make user unlimited (-1 credits)
        with get_db() as db:
            db.execute("UPDATE users SET credits = -1 WHERE user_id = ?", (user_id,))
        self.assertEqual(get_credits(user_id), -1)

        # 5. Test deduct with unlimited credits (should return True and credits remain -1)
        self.assertTrue(deduct_credits(user_id, 5000))
        self.assertEqual(get_credits(user_id), -1)

        # 6. Test add with unlimited credits (should do nothing and credits remain -1)
        add_credits(user_id, 1000)
        self.assertEqual(get_credits(user_id), -1)

if __name__ == "__main__":
    unittest.main()
